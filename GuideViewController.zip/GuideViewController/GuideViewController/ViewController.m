//
//  ViewController.m
//  GuideViewController
//
//  Created by yuantao on 16/11/10.
//  Copyright © 2016年 yuantao. All rights reserved.
//

#import "ViewController.h"
#import "GuideViewController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    GuideViewController *guide = [[GuideViewController alloc]init];
    guide.viewframe = self.view.bounds;
    UIView *view1 = [[UIView alloc]initWithFrame:self.view.bounds];
    view1.backgroundColor = [UIColor blueColor];
    UIView *view2 = [[UIView alloc]initWithFrame:self.view.bounds];
    view2.backgroundColor = [UIColor yellowColor];
    UIView *view3 = [[UIView alloc]initWithFrame:self.view.bounds];
    view3.backgroundColor = [UIColor orangeColor];
    UIView *view4 = [[UIView alloc]initWithFrame:self.view.bounds];
    view4.backgroundColor = [UIColor redColor];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(30, 100, 40, 60);
    [button setTitle:@"测试" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(tapbutton) forControlEvents:UIControlEventTouchUpInside];
    [view4 addSubview:button];
    
    guide.guidepagviewearr = @[view1, view2, view3, view4];
    [self addChildViewController:guide];
    [self.view addSubview:guide.view];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)tapbutton
{
    NSLog(@"cessss");
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
