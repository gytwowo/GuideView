//
//  GuideViewController.m
//  GuideViewController
//
//  Created by yuantao on 16/11/10.
//  Copyright © 2016年 yuantao. All rights reserved.
//

#import "GuideViewController.h"
@interface GuideViewController()<UIScrollViewDelegate>
{
    UIScrollView *_scrollview;
    UIView *_currentview;
    UIView *_nextview;
    
    CGFloat _startContentOffsetX;
    CGFloat _endContentOffsetX;
    NSInteger _currentindex;
}
@end
@implementation GuideViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.frame = self.viewframe;
    [self setScrollview];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)setScrollview{
    _scrollview = [[UIScrollView alloc]initWithFrame:self.viewframe];
    _scrollview.bounces = NO;
    _scrollview.showsVerticalScrollIndicator = NO;
    _scrollview.showsHorizontalScrollIndicator = NO;
    _scrollview.contentSize = CGSizeMake(self.viewframe.size.width*self.guidepagviewearr.count, self.viewframe.size.height);
    _scrollview.pagingEnabled = YES;
    _scrollview.backgroundColor = [UIColor redColor];
    _scrollview.delegate = self;
    [self.view addSubview:_scrollview];
    _currentview = self.guidepagviewearr[0];
    [_scrollview addSubview: _currentview];
}

#pragma mark UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    if (!_nextview) {
        if (scrollView.contentOffset.x>_startContentOffsetX) {
            _nextview = self.guidepagviewearr[_currentindex+1];
            CGRect frame = _nextview.frame;
            frame.origin.x = _currentview.frame.origin.x+self.viewframe.size.width;
            _nextview.frame = frame;
        }
        else if (scrollView.contentOffset.x<_startContentOffsetX) {
            _nextview = self.guidepagviewearr[_currentindex-1];
            CGRect frame = _nextview.frame;
            frame.origin.x = _currentview.frame.origin.x-self.viewframe.size.width;
            _nextview.frame = frame;
        }
        [_scrollview addSubview:_nextview];
    }
    
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{    //拖动前的起始坐标
    _currentindex = (NSInteger)(scrollView.contentOffset.x/self.viewframe.size.width);
    _startContentOffsetX = scrollView.contentOffset.x;
    
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
    _endContentOffsetX = scrollView.contentOffset.x;
    
    if (_endContentOffsetX != _startContentOffsetX) {
        [_currentview removeFromSuperview];
        _currentview = _nextview;
        _nextview = nil;
    }
    else {
        [_nextview removeFromSuperview];
        _nextview = nil;
    }
    
}


@end
